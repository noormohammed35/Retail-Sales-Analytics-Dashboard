# Screenshots

Export your Power BI report pages as images (File → Export → Export to Image, or a screen capture) and drop them here, e.g.:

- `sales-overview.png`
- `product-analysis.png`
- `regional-performance.png`
- `customer-segmentation.png`

Then reference them in the main `README.md` under the **Screenshots** section:

```markdown
![Sales Overview](docs/screenshots/sales-overview.png)
```
