# Data Model — Star Schema

```
                ┌────────────────┐
                │    DimDate      │
                │  Date (PK)      │
                │  Year, Quarter, │
                │  Month, Weekday │
                └────────┬────────┘
                         │ 1
                         │
        ┌────────────────┼────────────────┐
        │ *               │ *                │
┌───────┴───────┐  ┌──────┴───────┐  ┌───────┴────────┐
│  DimProduct    │  │  FactSales   │  │   DimRegion     │
│  ProductID(PK) ├──┤ ProductID(FK)│  │  RegionID (PK)  │
│  ProductName   │  │ RegionID(FK) ├──┤  Region         │
│  Category      │  │ CustomerID(FK)│ │  State/City     │
│  SubCategory   │  │ OrderDate    │  └─────────────────┘
└────────────────┘  │ Quantity     │
                     │ UnitPrice    │
                     │ Discount     │
                     │ SalesAmount  │
                     │ Cost         │
                     │ Profit       │
                     └──────┬───────┘
                            │ *
                            │
                   ┌────────┴────────┐
                   │  DimCustomer    │
                   │  CustomerID(PK) │
                   │  Segment        │
                   └─────────────────┘
```

## Relationships

| From | To | Cardinality | Cross-filter |
|---|---|---|---|
| `DimDate[Date]` | `FactSales[OrderDate]` | 1:* | Single |
| `DimProduct[ProductID]` | `FactSales[ProductID]` | 1:* | Single |
| `DimRegion[RegionID]` | `FactSales[RegionID]` | 1:* | Single |
| `DimCustomer[CustomerID]` | `FactSales[CustomerID]` | 1:* | Single |

## Design Notes

- Kept the fact table narrow and numeric-heavy for performance; all descriptive attributes live in dimension tables.
- `DimDate` is marked as the model's official Date Table (required for DAX time-intelligence functions).
- Cross-filter direction is single (dimension → fact) to avoid ambiguous filter paths.
- Hidden foreign key columns in the fact table from the Report view to reduce clutter in the field list.
