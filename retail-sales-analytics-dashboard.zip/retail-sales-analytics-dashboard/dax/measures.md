# DAX Measures

Core measures used across the Retail Sales Analytics Dashboard, grouped by category.

## Base Measures

```dax
Total Revenue = SUM(FactSales[SalesAmount])

Total Cost = SUM(FactSales[Cost])

Total Profit = SUM(FactSales[Profit])

Total Quantity = SUM(FactSales[Quantity])

Order Count = DISTINCTCOUNT(FactSales[OrderID])

Average Order Value = DIVIDE([Total Revenue], [Order Count], 0)

Profit Margin % = DIVIDE([Total Profit], [Total Revenue], 0)
```

## Time Intelligence

```dax
Sales YTD =
TOTALYTD([Total Revenue], DimDate[Date])

Sales QTD =
TOTALQTD([Total Revenue], DimDate[Date])

Sales MTD =
TOTALMTD([Total Revenue], DimDate[Date])

Sales PY (Prior Year) =
CALCULATE([Total Revenue], SAMEPERIODLASTYEAR(DimDate[Date]))

Sales PM (Prior Month) =
CALCULATE([Total Revenue], DATEADD(DimDate[Date], -1, MONTH))

Sales YoY Growth % =
DIVIDE([Total Revenue] - [Sales PY], [Sales PY], 0)

Sales MoM Growth % =
DIVIDE([Total Revenue] - [Sales PM], [Sales PM], 0)

Rolling 12M Sales =
CALCULATE(
    [Total Revenue],
    DATESINPERIOD(DimDate[Date], MAX(DimDate[Date]), -12, MONTH)
)
```

## Ranking & Top-N

```dax
Product Sales Rank =
RANKX(ALL(DimProduct[ProductName]), [Total Revenue], , DESC)

Top 5 Products Flag =
IF([Product Sales Rank] <= 5, "Top 5", "Other")

Contribution % of Total =
DIVIDE([Total Revenue], CALCULATE([Total Revenue], ALL(DimProduct)), 0)
```

## Customer / Segmentation

```dax
Customer Count = DISTINCTCOUNT(FactSales[CustomerID])

Revenue per Customer =
DIVIDE([Total Revenue], [Customer Count], 0)

New Customers =
CALCULATE(
    DISTINCTCOUNT(FactSales[CustomerID]),
    FILTER(
        VALUES(FactSales[CustomerID]),
        CALCULATE(MIN(FactSales[OrderDate])) = MIN(DimDate[Date])
    )
)
```

## Regional Comparison

```dax
Region Rank by Revenue =
RANKX(ALL(DimRegion[Region]), [Total Revenue], , DESC)

% of Total by Region =
DIVIDE([Total Revenue], CALCULATE([Total Revenue], ALL(DimRegion)), 0)
```

---

### Notes
- All measures assume a relationship between `FactSales[OrderDate]` and `DimDate[Date]` (single direction, DimDate → FactSales).
- Time-intelligence functions require `DimDate` to be marked as the official **Date Table** in the model.
- Wrap ratio measures in `DIVIDE()` (not `/`) to avoid divide-by-zero errors.
