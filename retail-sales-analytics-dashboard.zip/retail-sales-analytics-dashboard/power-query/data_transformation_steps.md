# Power Query (M) — Data Transformation Steps

This document lists the ETL steps applied in the Power Query Editor before loading data into the model.

## 1. Import Source Data

```m
let
    Source = Csv.Document(File.Contents("data/sample_retail_sales.csv"),
        [Delimiter=",", Columns=10, Encoding=65001, QuoteStyle=QuoteStyle.None]),
    PromotedHeaders = Table.PromoteHeaders(Source, [PromoteAllScalars=true])
in
    PromotedHeaders
```

## 2. Clean & Type Columns

```m
let
    Source = PromotedHeaders,
    ChangedType = Table.TransformColumnTypes(Source, {
        {"OrderDate", type date},
        {"Quantity", Int64.Type},
        {"UnitPrice", type number},
        {"Discount", type number},
        {"Region", type text},
        {"Category", type text},
        {"SubCategory", type text}
    }),
    RemovedDuplicates = Table.Distinct(ChangedType),
    RemovedNulls = Table.SelectRows(RemovedDuplicates, each [OrderDate] <> null and [Quantity] <> null)
in
    RemovedNulls
```

## 3. Add Calculated Columns

```m
let
    Source = RemovedNulls,
    AddedSalesAmount = Table.AddColumn(Source, "SalesAmount", each [Quantity] * [UnitPrice] * (1 - [Discount]), type number),
    AddedProfit = Table.AddColumn(AddedSalesAmount, "Profit", each [SalesAmount] * 0.25, type number),
    AddedMarginBucket = Table.AddColumn(AddedProfit, "MarginBucket",
        each if [Profit] / [SalesAmount] > 0.3 then "High"
        else if [Profit] / [SalesAmount] > 0.15 then "Medium"
        else "Low", type text)
in
    AddedMarginBucket
```

## 4. Split Category / Sub-Category

```m
let
    Source = AddedMarginBucket,
    SplitCategory = Table.SplitColumn(Source, "CategoryPath",
        Splitter.SplitTextByDelimiter(" - ", QuoteStyle.Csv), {"Category", "SubCategory"})
in
    SplitCategory
```

## 5. Build DimDate (Continuous Calendar Table)

```m
let
    StartDate = #date(2021, 1, 1),
    EndDate = #date(2026, 12, 31),
    NumberOfDays = Duration.Days(EndDate - StartDate) + 1,
    DateList = List.Dates(StartDate, NumberOfDays, #duration(1,0,0,0)),
    #"Converted to Table" = Table.FromList(DateList, Splitter.SplitByNothing(), {"Date"}),
    AddedYear = Table.AddColumn(#"Converted to Table", "Year", each Date.Year([Date]), Int64.Type),
    AddedQuarter = Table.AddColumn(AddedYear, "Quarter", each "Q" & Text.From(Date.QuarterOfYear([Date])), type text),
    AddedMonth = Table.AddColumn(AddedQuarter, "MonthName", each Date.MonthName([Date]), type text),
    AddedMonthNum = Table.AddColumn(AddedMonth, "MonthNumber", each Date.Month([Date]), Int64.Type),
    AddedWeekday = Table.AddColumn(AddedMonthNum, "WeekdayName", each Date.DayOfWeekName([Date]), type text)
in
    AddedWeekday
```

## 6. Unpivot Monthly Columns (if using wide-format source)

```m
let
    Source = RawWideTable,
    UnpivotedOther = Table.UnpivotOtherColumns(Source,
        {"Product", "Category", "Region"}, "Month", "SalesAmount")
in
    UnpivotedOther
```

---

**Applied Steps Summary (Power Query Editor pane order):**
1. Promoted headers
2. Changed column types
3. Removed duplicates
4. Filtered nulls
5. Added `SalesAmount`, `Profit`, `MarginBucket` columns
6. Split category path
7. Built `DimDate` as a separate query
8. Set data categories (e.g., `Region` → Geography)
9. Disabled load for staging/helper queries
